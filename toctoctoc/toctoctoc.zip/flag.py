def print_flag():
    with open('flag.txt', 'r') as f:
        print(f.read())
